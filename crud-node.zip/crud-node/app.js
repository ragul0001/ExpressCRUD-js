const express = require("express");
const database = require('./Database/sql');
const app = express();
app.use(express.json())

//CreateDatabase
app.get("/createDatabase", (req, res) => {
    let databaseName = "StudentData";
    let createQuery = `CREATE DATABASE IF NOT EXISTS  ${databaseName}`;
    // use the query to create a Database.
    database.query(createQuery, (err) => {
        if (err) throw err;
        console.log("Database Created Successfully !");
         
        let useQuery = `USE ${databaseName}`;
        database.query(useQuery, (error) => {
            if (error) throw error;
         
            console.log("Using Database");

            return res.send(
                `Created and Using ${databaseName} Database`);
        })
    });   
});
//Creat table inside of database
app.get("/table", (req, res) => {
    let databaseName = "TableData";
    let createQuery = `CREATE  TABLE IF NOT EXISTS ${databaseName} (id INT,name VARCHAR(255),email VARCHAR(255),City VARCHAR(255))` ;
    // use the query to create a Database.
    database.query(createQuery, (err) => {
        if (err) throw err;
        console.log("Table Created Successfully !");
        database.query(createQuery, (error) => {
            if (error) throw error;
            console.log("Using Database");
            return res.send(
                `Created and  ${databaseName} table`);
        })
    });   
});
//Insert Data into the table
app.get("/insert",(req,res)=>{
        const query=`INSERT INTO IF NOT EXISTS TableData (id,name,email,City) VALUES?`;
        const values=[
            [1,'RAGUL','ragul@gmail.com','Madurai'],
            [2,'Jash','Jash@gmail.com','Chennai'],
            [3,'KtM','Ktm@gmail.com','Madurai'],
            [4,'Karthi','karthi@gmail.com','Hyderbad'],
            [5,'RaviSastri','ravi@gmail.com','Gujarat']
        ];
        database.query(query,[values],(err,rows)=>{
                if(err) throw err;
                console.log("Data inserted");
                res.send("All Rows Inserted")
        });
})
//Selec and display the data
app.get('/select',(req,res)=>{
         var select=`SELECT * FROM TableData`
         database.query(select,(err,rows)=>{
            if(err) throw err;
            console.log(rows);
            res.send(JSON.parse(JSON.stringify(rows)));
         })
})
app.get('/selectid/:id',(req,res)=>{
        const RefId=req.params.id
        const query=`SELECT * FROM TableData WHERE id=?`;
        database.query(query,RefId,(err,rows)=>{
              if(err) throw err;
              console.log(JSON.parse(JSON.stringify(rows)));
              res.send(JSON.parse(JSON.stringify(rows)));
        })
})
//Update the data 
app.put('/updateid/:id',(req,res)=>{
    const RefId=req.params.id
    const name=req.body.name;
    const email=req.body.email;
    const City=req.body.City;

    database.query(`UPDATE TableData SET name=?,email=?,City=? WHERE id=?`,[name,email,City,RefId],(err,rows)=>{
          if(err) throw err;
          console.log("Updatedcl");
          res.send(JSON.parse(JSON.stringify(rows)));
    })
})
app.delete('/delete/:id',(req,res)=>{
    const RefId=req.params.id

    database.query(`DELETE  FROM TableData WHERE id=?`,RefId,(err,rows)=>{
          if(err) throw err;
          console.log("DELETED SUCESSFULLY");
          res.send("DELETED SUCESSFULLY");
    })
})

app.listen(4000, () => {
    console.log('Server is up and running on 8003');
})

